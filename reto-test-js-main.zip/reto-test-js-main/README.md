# reto-test-js
![image](https://user-images.githubusercontent.com/81586887/145028811-b96d921d-ef17-4036-bb0a-1d2d3d76250a.png)
![image](https://user-images.githubusercontent.com/81586887/145028893-ea8a1412-b8a4-48f7-a555-1581aededcba.png)
![image](https://user-images.githubusercontent.com/81586887/145029000-fd8a2acd-7c89-49ac-af3a-bdd7a5311729.png)
Autores:
Lainer Caceres Salas
Jhon Heiler Mosquera Cordoba
